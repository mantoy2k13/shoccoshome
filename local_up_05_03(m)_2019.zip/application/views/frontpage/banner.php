<header class="masthead bg-primary text-white text-center">	
   <?php if($is_page=="about"){ ?>
      <h1 class="m-t-25">About Us</h1>
   <?php } if($is_page=="contact"){  ?>
      <h1 class="m-t-25">Contact Us</h1>
   <?php } if($is_page=="user_agreement"){  ?>
      <h1 class="m-t-25">User Agreement</h1>
   <?php } if($is_page=="terms_and_conditions"){  ?>
      <h1 class="m-t-25">Terms and Conditions</h1>
  <?php } if($is_page=="policy"){  ?>
      <h1 class="m-t-25">Privacy Policy</h1>
   <?php }?>
   
</header>